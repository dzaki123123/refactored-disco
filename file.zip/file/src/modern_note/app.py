import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW, CENTER


class ModernNoteApp(toga.App):
    def startup(self):
        self.notes = []

        # Layout utama
        main_box = toga.Box(style=Pack(direction=COLUMN, padding=15))

        # Judul
        header = toga.Label(
            "📝 Modern Note",
            style=Pack(text_align=CENTER, font_size=20, padding_bottom=10)
        )

        # Input judul dan isi
        self.title_input = toga.TextInput(
            placeholder="Judul catatan...",
            style=Pack(padding=(5, 0), font_size=14)
        )
        self.content_input = toga.MultilineTextInput(
            placeholder="Tulis isi catatan di sini...",
            style=Pack(padding=(5, 0), flex=1, font_size=14)
        )

        # Tombol simpan
        save_button = toga.Button(
            "💾 Simpan",
            on_press=self.save_note,
            style=Pack(padding=10, alignment=CENTER, font_size=14)
        )

        # Label daftar catatan
        self.notes_list = toga.Box(style=Pack(direction=COLUMN, padding_top=10))

        # Susun elemen
        main_box.add(header)
        main_box.add(self.title_input)
        main_box.add(self.content_input)
        main_box.add(save_button)
        main_box.add(toga.Label("Catatan Tersimpan:", style=Pack(padding_top=10, font_size=14)))
        main_box.add(self.notes_list)

        # Jendela utama
        self.main_window = toga.MainWindow(title=self.formal_name)
        self.main_window.content = main_box
        self.main_window.show()

    def save_note(self, widget):
        title = self.title_input.value.strip()
        content = self.content_input.value.strip()

        if not title or not content:
            self.main_window.info_dialog("Peringatan", "Judul dan isi catatan tidak boleh kosong.")
            return

        note_label = toga.Label(
            f"📌 {title}: {content}",
            style=Pack(padding=5, font_size=13)
        )
        self.notes_list.add(note_label)

        # Simpan ke memori aplikasi
        self.notes.append({"title": title, "content": content})

        # Bersihkan input
        self.title_input.value = ""
        self.content_input.value = ""

        self.main_window.info_dialog("Berhasil", "Catatan disimpan di aplikasi!")



def main():
    return ModernNoteApp()